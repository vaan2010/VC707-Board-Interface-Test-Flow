#ifndef __XLWIPCONFIG_H_
#define __XLWIPCONFIG_H_


/* This is a generated file - do not edit */

#define XLWIP_CONFIG_INCLUDE_AXI_ETHERNET 1
#define XLWIP_CONFIG_INCLUDE_AXI_ETHERNET_DMA 1
#define XLWIP_CONFIG_N_TX_DESC 64
#define XLWIP_CONFIG_N_RX_DESC 64

#define XLWIP_CONFIG_N_TX_COALESCE 1
#define XLWIP_CONFIG_N_RX_COALESCE 1

#endif
