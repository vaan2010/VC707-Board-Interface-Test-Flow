/*
 * board_test_app.h
 *
 *  Created on: Feb 23, 2010
 */

#ifndef BOARD_TEST_APP_H_
#define BOARD_TEST_APP_H_

char inbyte(void );

int hello_button();
int hello_flash();
int FlashProtectionExample(void);
int lcd_simple(void);

#endif /* BOARD_TEST_APP_H_ */
